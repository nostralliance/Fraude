import pathlib
rootPath = pathlib.Path('images/')
tmpDir = '/depot/TMP/'
tmpDirImg = '/depot/image/'
dateFerieeDir = '/check/date_feriee/'
aucuneDir ='/check/aucune_fraude/'
finessDir = '/check/finess_faux/'
adhsusDir = '/check/Adherent_suspicieux/'
refArchDir = '/check/ref_arch_faux/'
nonSoumisRoDir = '/check/non_soumis_ro/'

#destinationPath =  pathlib.Path(rootPath + '/check/')
#destinationPixel = pathlib.Path(destinationPath + '/modification_pixel/')
#destinationDateFeriee = pathlib.Path(destinationPath + '/date_feriee/')
#destinationRo = pathlib.Path(destinationPath + '/non_soumis_ro/')
#destination = pathlib.Path(destinationPath + '/ref_arch_faux/')
#destinationAucune = pathlib.Path(destinationPath + '/aucune_fraude')
#destinationFiness = pathlib.Path(destinationPath + '/finess_faux')
#dateFerieeDir= '/check/date_feriee/'
#destinationDateFeriee = '/check/date_feriee/'